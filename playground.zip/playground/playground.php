<!DOCTYPE html>
<html>
<?php include 'partials/head.php'; ?>
<body>
<?php include 'partials/navigation.php' ?>
</body>
<script>
</script>

</html>