<?php
?>
<!doctype html>
<html lang="en">
<?php include 'partials/head.php'; ?>
<style>
    body {
        background: url("assets/img/JOKER_BACKGROUND.jpg") no-repeat center center fixed;
        background-size: cover;
    }

</style>
<body>
<?php include 'partials/navigation.php' ?>
</body>
</html>
