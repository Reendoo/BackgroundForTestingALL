<?php
$file_path = $_SERVER['DOCUMENT_ROOT'] . "/assets/sin-city/storage.json";

?>