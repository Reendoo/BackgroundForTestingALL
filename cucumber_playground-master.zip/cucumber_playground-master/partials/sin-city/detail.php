<div class="col-md-5 col-md-offset-1 detail">
    <img class="loader" src="../../assets/img/ajax-loader.gif" alt="">
    <h3>detail of sin</h3>
    <article>
        <h4>
            <datetime></datetime>
        </h4>
        <p></p>
        <div class="tags">
            <h5>tags</h5>
            <ul></ul>
        </div>
    </article>
</div>